package com.example.barangkelontong;

///CLASS UNTUK BARANG INPUT
public class Barang {
    private String imgName;
    private String imgUrl;
    private String kode;
    private String satuan;
    private String expDate;
    private String harga;
    private String jumlah;
    private String key;

    public String getExpDate() {
        return expDate;
    }

    public void setExpDate(String expDate) {
        this.expDate = expDate;
    }

    public String getSatuan() {
        return satuan;
    }

    public void setSatuan(String satuan) {
        this.satuan = satuan;
    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getKode() {
        return kode;
    }

    public void setKode(String kode) {
        this.kode = kode;
    }

    public String getJumlah() {
        return jumlah;
    }

    public void setJumlah(String jumlah) {
        this.jumlah=jumlah;
    }

    public Barang() {
    }

    public Barang(String kode1, String imgName1, String satuan1, String expDate1, String harga1, String jumlah1, String imgUrl1) {

        this.kode=kode1;
        this.imgName = imgName1;
        this.satuan=satuan1;
        this.expDate=expDate1;
        this.harga=harga1;
        this.jumlah=jumlah1;
        this.imgUrl = imgUrl1;
    }

    public String getImgName() {
        return imgName;
    }

    public void setImgName(String imgName) {
        this.imgName = imgName;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }
}
