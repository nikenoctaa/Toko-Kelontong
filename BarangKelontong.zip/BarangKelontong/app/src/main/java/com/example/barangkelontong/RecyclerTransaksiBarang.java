package com.example.barangkelontong;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

import java.util.List;

//Class Adapter ini Digunakan Untuk Mengatur Bagaimana Data akan Ditampilkan
public class RecyclerTransaksiBarang extends RecyclerView.Adapter<RecyclerTransaksiBarang.transaksiViewHolder> {

    private Context mContext;
    private List<Barang> mBarang;

    //adapter untuk transaksi
    public RecyclerTransaksiBarang(Context context, List<Barang> barang){
        mContext = context;
        mBarang = barang;
    }

    //inflate layout view_stok_transaksi
    @NonNull
    @Override
    public transaksiViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.view_stok_transaksi, parent, false);
        return new RecyclerTransaksiBarang.transaksiViewHolder(v);
    }

    ///menampilkan data barang sesuai data yang diambil
    @Override
    public void onBindViewHolder(@NonNull final transaksiViewHolder holder, final int position) {
        final Barang uploadTransaksi = mBarang.get(position);
        holder.xnama.setText(" " + uploadTransaksi.getImgName());
        holder.xjumlah.setText(" " + uploadTransaksi.getJumlah());
        holder.xharga.setText(" " + uploadTransaksi.getHarga());
        Picasso.with(mContext)
                .load(uploadTransaksi.getImgUrl())
                .placeholder(R.drawable.selection_image)
                .fit()
                .centerCrop()
                .into(transaksiViewHolder.xgambar);
        ///jika klik button beli maka dia akan ambil data kemudian di intent ke kelas Beli barang
        transaksiViewHolder.btnBelii.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("dataNama", mBarang.get(position).getImgName());
                bundle.putString("dataJumlah", mBarang.get(position).getJumlah());
                bundle.putString("dataHarga", mBarang.get(position).getHarga());
                bundle.putString("dataGambar", mBarang.get(position).getImgUrl());
                bundle.putString("getPrimaryKey", mBarang.get(position).getKey());
                Intent intent = new Intent(v.getContext(), BeliBarang.class);
                intent.putExtras(bundle);
                mContext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mBarang.size();
    }
    ///mendapatkan / memanggil id sesuai pada xml
    public static class transaksiViewHolder extends RecyclerView.ViewHolder {
        public static TextView xnama, xjumlah, xharga;
        public static ImageView xgambar;
        public static EditText jmlBeli;
        public static Button btnBelii;
        public static LinearLayout listItem;
        public static FirebaseAuth Auth;
        public static DatabaseReference db;
        public transaksiViewHolder(@NonNull View itemView) {
            super(itemView);
            xnama = itemView.findViewById(R.id.vnama);
            xjumlah = itemView.findViewById(R.id.vjumlah);
            xharga = itemView.findViewById(R.id.vharga);
            xgambar = itemView.findViewById(R.id.vgambar);
            listItem = itemView.findViewById(R.id.list_item_terjual);
            btnBelii = itemView.findViewById(R.id.belii);
            Auth = FirebaseAuth.getInstance();
            db= FirebaseDatabase.getInstance().getReference();
        }
    }
}

