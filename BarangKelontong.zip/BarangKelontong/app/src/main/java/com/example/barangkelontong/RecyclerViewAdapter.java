package com.example.barangkelontong;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

import java.util.List;

//Class Adapter ini Digunakan Untuk Mengatur Bagaimana Data akan Ditampilkan
public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ImageViewHolder> {

    private Context mContext;
    private List<Barang> mBarang;

    //make interface
    public interface dataListener{
        void onDeleteData(Barang data, int position);
    }

    //object declaration from interface
    dataListener listener;

    //adapter untuk tambah barang
    public RecyclerViewAdapter(Context context, List<Barang> barang) {
        mContext = context;
        mBarang = barang;
        listener = (ListStokBarang) context;
    }

    //inflater ke view stok barang
    @NonNull
    @Override
    public ImageViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.view_stok_barang, viewGroup, false);
        return new ImageViewHolder(v);
    }

    //parsing data
    @Override
    public void onBindViewHolder(@NonNull final ImageViewHolder imageViewHolder, final int i) {
        ///mengambil data yang dipilih
        final Barang uploadBarang = mBarang.get(i);
        imageViewHolder.xkode.setText("Kode Barang\t: " + uploadBarang.getKode());
        imageViewHolder.xnama.setText("Nama Barang\t: " + uploadBarang.getImgName());
        imageViewHolder.xsatuan.setText("Satuan Barang\t: " + uploadBarang.getSatuan());
        imageViewHolder.xjumlah.setText("Jumlah Barang\t: " + uploadBarang.getJumlah());
        imageViewHolder.xtanggal.setText("Tanggal Barang\t: " + uploadBarang.getExpDate());
        imageViewHolder.xharga.setText("Harga Barang\t: " + uploadBarang.getHarga());
        Picasso.with(mContext)
                .load(uploadBarang.getImgUrl())
                .placeholder(R.drawable.selection_image)
                .fit()
                .centerCrop()
                .into(imageViewHolder.xgambar);

        //long klik untuk pilih update atau detele
        imageViewHolder.listItem.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(final View v) {
                final String[] action = {"Update", "Delete"};
                AlertDialog.Builder alert = new AlertDialog.Builder(v.getContext());
                alert.setItems(action, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which){
                            case 0:
                                //parsing data ke update barang
                                Bundle bundle = new Bundle();
                                bundle.putString("dataKode", mBarang.get(i).getKode());
                                bundle.putString("dataNama", mBarang.get(i).getImgName());
                                bundle.putString("dataSatuan", mBarang.get(i).getSatuan());
                                bundle.putString("dataJumlah", mBarang.get(i).getJumlah());
                                bundle.putString("dataTanggal", mBarang.get(i).getExpDate());
                                bundle.putString("dataHarga", mBarang.get(i).getHarga());
                                bundle.putString("dataGambar", mBarang.get(i).getImgUrl());
                                bundle.putString("getPrimaryKey", mBarang.get(i).getKey());
                                Intent intent = new Intent(v.getContext(), UpdateBarang.class);
                                intent.putExtras(bundle);
                                mContext.startActivity(intent);
                                break;
                            case 1:
                                //Menggunakan interface untuk mengirim data yang akan dihapus
                                listener.onDeleteData(mBarang.get(i), i);
                                break;
                        }
                    }
                });
                alert.create();
                alert.show();
                return true;
            }
        });
    }

    @Override
    public int getItemCount() {
        return mBarang.size();
    }

    //hitung mBarang jumlahe ada berapa
    public class ImageViewHolder extends RecyclerView.ViewHolder {
        public TextView xkode, xnama, xsatuan, xjumlah, xtanggal, xharga;
        public ImageView xgambar;
        public LinearLayout listItem;

        public ImageViewHolder(@NonNull View itemView) {
            super(itemView);
            xkode = itemView.findViewById(R.id.vkode);
            xnama = itemView.findViewById(R.id.vnama);
            xsatuan = itemView.findViewById(R.id.vsatuan);
            xjumlah = itemView.findViewById(R.id.vjumlah);
            xtanggal = itemView.findViewById(R.id.vtanggal);
            xharga = itemView.findViewById(R.id.vharga);
            xgambar = itemView.findViewById(R.id.vgambar);
            listItem = itemView.findViewById(R.id.list_item);

        }
    }
}
