package com.example.barangkelontong;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;

import java.util.ArrayList;
import java.util.List;

public class ListStokTransaksi extends AppCompatActivity {


    private RecyclerView mRecyclerVieww;
    private RecyclerTransaksiBarang mAdapter;
    private SearchView searchh;

    private ProgressBar progressBar;

    private DatabaseReference mDatabaseRef;
    private FirebaseStorage mStorageRef;
    private FirebaseAuth mAuth;
    private Button vieww;
    private List<Barang> mBarang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_list_stok_transaksi);
        mRecyclerVieww=findViewById(R.id.listTransaksi);
        mRecyclerVieww.setHasFixedSize(true);
        mRecyclerVieww.setLayoutManager(new GridLayoutManager(this,2));

        searchh = findViewById(R.id.seach1);
        progressBar=findViewById(R.id.progress_circular);
        mAuth=FirebaseAuth.getInstance();
        vieww = findViewById(R.id.btnview);
        vieww.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent i = new Intent(ListStokTransaksi.this,BarangTerjual.class);
                startActivity(i);
            }
        });

        mBarang=new ArrayList<>();
        mDatabaseRef= FirebaseDatabase.getInstance().getReference();
        mStorageRef = FirebaseStorage.getInstance();
    }


    protected void onStart(){
        super.onStart();
        if(mDatabaseRef != null){
            //ambil data/ value dari barang
            mDatabaseRef.child("Users").child("username").child("Barang_kelontong").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                        Barang transaksi = postSnapshot.getValue(Barang.class);
                        transaksi.setKey(postSnapshot.getKey());
                        mBarang.add(transaksi);
                    }
                    mAdapter = new RecyclerTransaksiBarang(ListStokTransaksi.this, mBarang);
                    mRecyclerVieww.setAdapter(mAdapter);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(ListStokTransaksi.this, databaseError.getMessage(), Toast.LENGTH_LONG).show();
                    progressBar.setVisibility(View.INVISIBLE);
                }
            });
        }

        //melakukan searching
        searchh.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                Toast t = Toast.makeText(ListStokTransaksi.this, "tes", Toast.LENGTH_SHORT);
                t.show();
                return false;
            }
        });
//        if (searchh != null){
        searchh.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                //Toast.makeText(BarangTerjual.this, query, Toast.LENGTH_LONG).show();
                mBarang.clear();
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (searchh != null) {
                    cari(newText);
                    return true;
                } else if(TextUtils.isEmpty(newText)) {
                    Toast.makeText(ListStokTransaksi.this, "Test 1", Toast.LENGTH_SHORT).show();
                    return true;
                }else{
                    Toast.makeText(ListStokTransaksi.this, "Test 2", Toast.LENGTH_SHORT).show();
                    return true;
                }
            }
        });
    }

    //searching based on child in database
    private void cari(String newText) {
        mBarang.clear();
        Query query = mDatabaseRef.child("Users").child("username").child("Barang_kelontong").orderByChild("imgName").startAt(newText).endAt(newText+"\uf8ff");
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    Barang transaksi = postSnapshot.getValue(Barang.class);
                    transaksi.setKey(postSnapshot.getKey());
                    mBarang.add(transaksi);
                }
                mAdapter = new RecyclerTransaksiBarang(ListStokTransaksi.this, mBarang);
                mRecyclerVieww.setAdapter(mAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(ListStokTransaksi.this, databaseError.getMessage(), Toast.LENGTH_LONG).show();
                progressBar.setVisibility(View.INVISIBLE);
            }
        });
    }

}
