package com.example.barangkelontong;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class RecyclerBarangTerjual extends RecyclerView.Adapter<RecyclerBarangTerjual.terjualViewHolder> {

    private Context mContext;
    private List<Jual> mJual;

    //adapter untuk barang terjual
    public  RecyclerBarangTerjual(Context context, List<Jual> jual){
        mContext=context;
        mJual=jual;

    }

    @NonNull
    @Override
    public terjualViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(mContext).inflate(R.layout.view_stok_terjual, parent,false);
        return  new RecyclerBarangTerjual.terjualViewHolder(v);
    }

    //untuk menampilkan data barang sesuai data yang diambil
    @Override
    public void onBindViewHolder(@NonNull terjualViewHolder holder, int position) {
        Jual beliCur=mJual.get(position);

        holder.img_name.setText("Nama Barang\t\t: "+beliCur.getName());
        holder.img_harga.setText("Harga Barang\t\t: "+beliCur.getHarga());
        holder.img_jumlah.setText("Jumlah Barang\t: "+beliCur.getJumlah());
        holder.img_total.setText("Total Harga\t: "+beliCur.getTotal());

    }

    @Override
    public int getItemCount() {
        return mJual.size();
    }

    /// untuk memanggil id sesuai pada yang tertera di xml
    public class terjualViewHolder extends RecyclerView.ViewHolder {
        public TextView img_name, img_harga, img_jumlah, img_total;
        public terjualViewHolder(@NonNull View itemView) {
            super(itemView);

            img_name=itemView.findViewById(R.id.namaTerjual);
            img_harga=itemView.findViewById(R.id.hargaTerjual);
            img_jumlah=itemView.findViewById(R.id.jumlahTerjual);
            img_total=itemView.findViewById(R.id.totalTerjual);
        }
    }

}
