package com.example.barangkelontong;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.annotations.Nullable;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;


public class BarangTerjual extends AppCompatActivity {

    private RecyclerView mRecyclerView;
    private RecyclerBarangTerjual mAdapter;
    private Button xback;

    private ProgressBar progressBar;

    private DatabaseReference mDatabaseRef;
    private FirebaseStorage mStorageRef;
    private FirebaseAuth mAuth;
    private SearchView search;

    private List<Jual> mJual;
    private List<Jual> listSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_barang_terjual);
        mRecyclerView = findViewById(R.id.listBarangTerjual);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        xback = findViewById(R.id.btnBack);
        search = findViewById(R.id.searchView);
        progressBar = findViewById(R.id.progress_circular);
        mAuth = FirebaseAuth.getInstance();
        mJual = new ArrayList<>();
        mDatabaseRef = FirebaseDatabase.getInstance().getReference();
        mStorageRef = FirebaseStorage.getInstance();

        //intent button back from BarangJual to menu
        xback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(BarangTerjual.this, Menu.class));
            }
        });

    }


    @Override
    protected void onStart() {
        super.onStart();
        //Get value from Jual Class
        if (mDatabaseRef != null) {
            mDatabaseRef.child("Users").child("username").child("Barang_terjual").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                        Jual jual = postSnapshot.getValue(Jual.class);
                        jual.setKey(postSnapshot.getKey());
                        mJual.add(jual);
                    }
                    mAdapter = new RecyclerBarangTerjual(BarangTerjual.this, mJual);
                    mRecyclerView.setAdapter(mAdapter);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(BarangTerjual.this, databaseError.getMessage(), Toast.LENGTH_LONG).show();
                    progressBar.setVisibility(View.INVISIBLE);
                }
            });
        }

        //untuk searching
        search.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                Toast t = Toast.makeText(BarangTerjual.this, "tes", Toast.LENGTH_SHORT);
                t.show();
                return false;
            }
        });
//        if (searchh != null){
        search.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                //Toast.makeText(BarangTerjual.this, query, Toast.LENGTH_LONG).show();
                mJual.clear();
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (search != null) {
                    cari(newText);
                    return true;
                } else if(TextUtils.isEmpty(newText)) {
                    Toast.makeText(BarangTerjual.this, "Test 1", Toast.LENGTH_SHORT).show();
                    return true;
                }else{
                    Toast.makeText(BarangTerjual.this, "Test 2", Toast.LENGTH_SHORT).show();
                    return true;
                }
            }
        });
    }

    //untuk searching based on child in firebase
    private void cari(String newText) {
        mJual.clear();
        Query query = mDatabaseRef.child("Users").child("username").child("Barang_terjual").orderByChild("name").startAt(newText).endAt(newText+"\uf8ff");
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    Jual jual = postSnapshot.getValue(Jual.class);
                    jual.setKey(postSnapshot.getKey());
                    mJual.add(jual);
                }
                mAdapter = new RecyclerBarangTerjual(BarangTerjual.this, mJual);
                mRecyclerView.setAdapter(mAdapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(BarangTerjual.this, databaseError.getMessage(), Toast.LENGTH_LONG).show();
                progressBar.setVisibility(View.INVISIBLE);
            }
        });
    }
}

