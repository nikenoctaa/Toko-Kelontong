package com.example.barangkelontong;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;

import java.util.ArrayList;
import java.util.List;

public class ListStokBarang extends AppCompatActivity implements RecyclerViewAdapter.dataListener {

    Button xtambah;

    private RecyclerView mRecyclerView;
    private RecyclerViewAdapter mAdapter;

    private ProgressBar progressBar;

    private DatabaseReference mDatabaseRef;
    private FirebaseStorage mStorageRef;
    private FirebaseAuth mAuth;

    private List<Barang> mBarang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_list_stok_barang);
        mRecyclerView=findViewById(R.id.listbarang);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        xtambah = findViewById(R.id.add_barang);

        progressBar=findViewById(R.id.progress_circular);
        mAuth=FirebaseAuth.getInstance();

        mBarang=new ArrayList<>();
        mDatabaseRef= FirebaseDatabase.getInstance().getReference();
        mStorageRef = FirebaseStorage.getInstance();

        ///get data dari firebase
        mDatabaseRef.child("Users").child("username").child("Barang_kelontong").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    Barang barang = postSnapshot.getValue(Barang.class);
                    barang.setKey(postSnapshot.getKey());
                    mBarang.add(barang);
                }
                mAdapter = new RecyclerViewAdapter(ListStokBarang.this, mBarang);
                mRecyclerView.setAdapter(mAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(ListStokBarang.this, databaseError.getMessage(), Toast.LENGTH_LONG).show();
                progressBar.setVisibility(View.INVISIBLE);
            }
        });

        //intent tombol tambah ke menu main / untuk tambah barang
        xtambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ListStokBarang.this, MainActivity.class));
            }
        });
    }

    // delete data
    @Override
    public void onDeleteData(Barang data, int position) {
        /*
         * Kode ini akan dipanggil ketika method onDeleteData
         * dipanggil dari adapter pada RecyclerView melalui interface.
         * kemudian akan menghapus data berdasarkan primary key dari data tersebut
         * Jika berhasil, maka akan memunculkan Toast
         */
        //String userID = auth.getUid();
        if(mDatabaseRef != null){
            mDatabaseRef.child("Users").child("username").child("Barang_kelontong")
                    .child(data.getKey())
                    .removeValue()
                    .addOnSuccessListener(new OnSuccessListener() {
                        @Override
                        public void onSuccess(Object o) {
                            Toast.makeText(ListStokBarang.this, "Data Berhasil Dihapus", Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }
}
