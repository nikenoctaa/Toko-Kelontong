package com.example.barangkelontong;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;

public class Menu extends AppCompatActivity implements View.OnClickListener{

    private Button btnAboutUs,btnStok,btnTransaksi,btnSignOut;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_menu);

        //inisialisasi tombol
        btnAboutUs = (Button)findViewById(R.id.about_us);
        btnAboutUs.setOnClickListener(this);
        btnStok = (Button)findViewById(R.id.stokBarang);
        btnStok.setOnClickListener(this);
        btnTransaksi = (Button)findViewById(R.id.transaksi);
        btnTransaksi.setOnClickListener(this);
        btnSignOut = (Button)findViewById(R.id.keluar);
        btnSignOut.setOnClickListener(this);

        mAuth=FirebaseAuth.getInstance();
    }

    //intent menu sesuai tombol
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.stokBarang:
                Intent listStokBarang = new Intent (Menu.this, ListStokBarang.class);
                startActivity(listStokBarang);
                break;
            case R.id.about_us:
                Intent aboutUs = new Intent(Menu.this, AboutUs.class);
                startActivity(aboutUs);
                break;
            case R.id.transaksi:
                Intent listStokTransaksi = new Intent (Menu.this, ListStokTransaksi.class);
                startActivity(listStokTransaksi);
                break;
            case R.id.keluar:
                mAuth.signOut();
                finish();
                break;
        }
    }
}
