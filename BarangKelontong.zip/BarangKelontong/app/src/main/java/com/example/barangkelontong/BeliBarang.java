package com.example.barangkelontong;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.ContactsContract;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.annotations.Nullable;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

public class BeliBarang extends AppCompatActivity {

    private Button  btnBeli;
    private Button listTerjual;
    private ImageView imgPreview;
    private EditText namaBrgBeli, hargaBrgBeli, jmlBrgBeli, totalBrgBeli;

    private DatabaseReference mDatabaseRef;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_beli_barang);

        btnBeli = findViewById(R.id.btnBeli);

        namaBrgBeli = findViewById(R.id.namaBrgBeli);
        imgPreview = findViewById(R.id.viewImage);
        hargaBrgBeli = findViewById(R.id.hrgBrgBeli);
        jmlBrgBeli = findViewById(R.id.jmlBrgBeli);
        totalBrgBeli = findViewById(R.id.totalBrgBeli);
        listTerjual = findViewById(R.id.btnView);

        mAuth=FirebaseAuth.getInstance();

        mDatabaseRef = FirebaseDatabase.getInstance().getReference();


        getData();
        btnBeli.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                beliBarang();
            }
        });

        listTerjual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void beliBarang() {
        Toast.makeText(BeliBarang.this, "Buy successfully", Toast.LENGTH_LONG).show();
        // melakukan perhitungan, apabila dia membeli maka stok barang akan berkurang
        final String keyy = getIntent().getExtras().getString("getPrimaryKey");
        final int jmlJual = Integer.parseInt(jmlBrgBeli.getText().toString().trim());
        final int jmlBrg = Integer.parseInt(getIntent().getExtras().getString("dataJumlah"));
        // mengurangi jumlah barang sesuai yang dijual
        final int jmlUpdate = jmlBrg - jmlJual;
        final String jml_Update = String.valueOf(jmlUpdate);

        //parsing harga sesuai harga yang dijual
        final int hrg = Integer.parseInt(hargaBrgBeli.getText().toString().trim());
        //melakukan pembayaran sesuai dengan jumlah barang yang dijual
        final int byr = jmlJual * hrg;
        final String bayar = String.valueOf(byr);


        //set value jual
        Jual jual = new Jual(namaBrgBeli.getText().toString().trim(), jmlBrgBeli.getText().toString().trim(),hargaBrgBeli.getText().toString().trim(),bayar);
        imgPreview.setImageResource(R.drawable.selection_image);
        namaBrgBeli.setText(namaBrgBeli.getText().toString());
        jmlBrgBeli.setText("");
        hargaBrgBeli.setText("");
        totalBrgBeli.setText(bayar);
        //push ke child
        mDatabaseRef.child("Users").child("username").child("Barang_terjual").push().setValue(jual);
        mDatabaseRef.child("Users").child("username").child("Barang_kelontong").child(keyy).child("jumlah").setValue(jml_Update);
        startActivity(new Intent(getApplicationContext(), BarangTerjual.class));
    }

    private void getData() {
        // untuk mengambil data sesuai yang dipanggil
        final String getNama = getIntent().getExtras().getString("dataNama");
        final String getHarga = getIntent().getStringExtra("dataHarga");
        final String getJumlah = getIntent().getStringExtra("dataJumlah");
        final String getTotal = getIntent().getStringExtra("dataTotal");
        final String getUrlimg = getIntent().getStringExtra("dataGambar");
        //untuk menampilkan data yang dimasukan
        namaBrgBeli.setText(getNama);
        jmlBrgBeli.setText(getJumlah);
        hargaBrgBeli.setText(getHarga);
        totalBrgBeli.setText(getTotal);
        Picasso.with(this).load(getUrlimg).into(imgPreview);
    }
}
