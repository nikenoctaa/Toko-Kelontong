package com.example.barangkelontong;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

import java.util.Calendar;

import static android.text.TextUtils.isEmpty;

public class UpdateBarang extends AppCompatActivity {

    private Button btnUpdate, btnBack, vieww;
    private DatePickerDialog picker;
    private ImageView vimage;
    private EditText  vnama, vkode, vjumlah, vsatuan, vtanggal, vharga;
    private String cekKode, cekNama, cekJumlah, cekSatuan, cekTanggal, cekHarga;

    private DatabaseReference mDatabaseRef;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_update_barang);
        getSupportActionBar().setTitle("Update Data");

        btnUpdate = findViewById(R.id.tblAdd);

        vimage = findViewById(R.id.pilImage);
        vkode = findViewById(R.id.uKode);
        vnama = findViewById(R.id.uNama);
        vsatuan = findViewById(R.id.uSatuan);
        vjumlah = findViewById(R.id.uJumlah);
        vharga = findViewById(R.id.uHarga);
        vtanggal = findViewById(R.id.uTanggal);
        //set tanggal
        vtanggal.setInputType(InputType.TYPE_NULL);
        vtanggal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar cldr = Calendar.getInstance();
                int day = cldr.get(Calendar.DAY_OF_MONTH);
                int month = cldr.get(Calendar.MONTH);
                int year = cldr.get(Calendar.YEAR);

                picker = new DatePickerDialog(UpdateBarang.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                vtanggal.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                            }
                        }, year, month, day);
                picker.show();
            }
        });




        mAuth=FirebaseAuth.getInstance();
        mDatabaseRef = FirebaseDatabase.getInstance().getReference();

        getData();
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cekKode = vkode.getText().toString();
                cekNama = vnama.getText().toString();
                cekTanggal = vtanggal.getText().toString();
                cekSatuan = vsatuan.getText().toString();
                cekJumlah = vjumlah.getText().toString();
                cekHarga = vharga.getText().toString();

                //Mengecek agar tidak ada data yang kosong, saat proses update
                if(isEmpty(cekKode) || isEmpty(cekNama) || isEmpty(cekTanggal)|| isEmpty(cekSatuan) || isEmpty(cekJumlah) || isEmpty(cekHarga)){
                    Toast.makeText(UpdateBarang.this, "Data tidak boleh ada yang kosong", Toast.LENGTH_SHORT).show();
                }else {
                    /*
                      Menjalankan proses update data.
                      Method Setter digunakan untuk mendapakan data baru yang diinputkan User.
                    */
                    Barang setBarang = new Barang();
                    setBarang.setImgUrl(getIntent().getExtras().getString("dataGambar"));
                    setBarang.setKode(vkode.getText().toString());
                    setBarang.setImgName(vnama.getText().toString());
                    setBarang.setExpDate(vtanggal.getText().toString());
                    setBarang.setSatuan(vsatuan.getText().toString());
                    setBarang.setJumlah(vjumlah.getText().toString());
                    setBarang.setHarga(vharga.getText().toString());
                    updateBarang(setBarang);
                }
            }
        });
    }

    private boolean isEmpty(String s) {
        return TextUtils.isEmpty(s);
    }

    //get data yang dipilih
    private void getData() {
        final String getKode = getIntent().getStringExtra("dataKode");
        final String getNama = getIntent().getExtras().getString("dataNama");
        final String getSatuan = getIntent().getStringExtra("dataSatuan");
        final String getJumlah = getIntent().getStringExtra("dataJumlah");
        final String getTanggal = getIntent().getExtras().getString("dataTanggal");
        final String getHarga = getIntent().getStringExtra("dataHarga");
        final String getUrlimg = getIntent().getStringExtra("dataGambar");

        //memasukan atau meng nge set data yang di input, atau memasukan data
        vkode.setText(getKode);
        vnama.setText(getNama);
        vsatuan.setText(getSatuan);
        vjumlah.setText(getJumlah);
        vtanggal.setText(getTanggal);
        vharga.setText(getHarga);
        Picasso.with(this).load(getUrlimg).into(vimage);
    }

    //untuk update barang sesuai data yang dipanggil di firebase
    private void updateBarang(Barang barang) {
        String getKey = getIntent().getExtras().getString("getPrimaryKey");
        mDatabaseRef.child("Users").child("username").child("Barang_kelontong").child(getKey).setValue(barang).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                vimage.setImageResource(R.drawable.selection_image);
                vkode.setText(vkode.getText().toString());
                vnama.setText("");
                vsatuan.setText("");
                vjumlah.setText("");
                vtanggal.setText("");
                vharga.setText("");
                ///toast jika data berhasil di update
                Toast.makeText(UpdateBarang.this, "Data Berhasil diubah", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }
}
