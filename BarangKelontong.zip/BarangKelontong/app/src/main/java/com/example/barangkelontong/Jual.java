package com.example.barangkelontong;

//CLASS UNTUK BARANG JUAL
public class Jual {
    String name;
    String harga;
    String jumlah;
    String total;
    private String key;

    public Jual() {
    }

    public Jual(String name1, String jumlah1, String harga1, String total) {

        this.name = name1;
        this.harga = harga1;
        this.jumlah = jumlah1;
        this.total = total;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getJumlah() {
        return jumlah;
    }

    public void setJumlah(String jumlah) {
        this.jumlah = jumlah;
    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }
}
